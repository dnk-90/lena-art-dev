import lenartLogo from "@/assets/lenart-logo.png.asset.json";
import heroTigar from "@/assets/hero-jelena-tigar.webp.asset.json";
import usne from "@/assets/jelena-usne.webp.asset.json";
import svetiNikola from "@/assets/jelena-sveti-nikola.webp.asset.json";
import isusHrist from "@/assets/ikona-isus-hrist.webp.asset.json";
import pejzaz from "@/assets/pejzaz-uramljen.webp.asset.json";
import parSrce from "@/assets/par-srce.webp.asset.json";
import atelje from "@/assets/jelena-atelje-crvena.webp.asset.json";
import oMeni from "@/assets/jelena-o-meni.jpg.asset.json";
import gospodPredZemljom from "@/assets/gospod-pred-zemljom.jpg.asset.json";
import polaPola from "@/assets/pola-pola.jpg.asset.json";
import svetaPetka from "@/assets/sveta-petka.jpg.asset.json";
import mlada from "@/assets/mlada.jpg.asset.json";
import gospodPruzaRuku from "@/assets/gospod-pruza-ruku.jpg.asset.json";
import reci from "@/assets/reci.jpg.asset.json";
import novakDjokovic from "@/assets/novak-djokovic.jpg.asset.json";
import osvetljenPut from "@/assets/osvetljen-put.jpg.asset.json";
import svetaPetkaIkona from "@/assets/sveta-petka-ikona.jpg.asset.json";
import ruza from "@/assets/ruza.jpg.asset.json";
import svetiVasilije from "@/assets/sveti-vasilije.jpg.asset.json";
import tamjan from "@/assets/tamjan.jpg.asset.json";
import patrijarhPavle from "@/assets/patrijarh-pavle.jpg.asset.json";

export const IMAGES = {
  logo: lenartLogo.url,
  heroTigar: heroTigar.url,
  usne: usne.url,
  svetiNikola: svetiNikola.url,
  isusHrist: isusHrist.url,
  pejzaz: pejzaz.url,
  parSrce: parSrce.url,
  atelje: atelje.url,
  oMeni: oMeni.url,
  gospodPredZemljom: gospodPredZemljom.url,
  polaPola: polaPola.url,
  svetaPetka: svetaPetka.url,
  mlada: mlada.url,
  gospodPruzaRuku: gospodPruzaRuku.url,
  reci: reci.url,
  novakDjokovic: novakDjokovic.url,
  osvetljenPut: osvetljenPut.url,
  svetaPetkaIkona: svetaPetkaIkona.url,
  ruza: ruza.url,
  svetiVasilije: svetiVasilije.url,
  tamjan: tamjan.url,
  patrijarhPavle: patrijarhPavle.url,
};

export const CONTACT = {
  phoneDisplay: "064 490 5335",
  phoneIntl: "+381 64 490 5335",
  tel: "tel:+381644905335",
  email: "lenaartbusiness@gmail.com",
  mailto: "mailto:lenaartbusiness@gmail.com",
  instagram: "https://www.instagram.com/____lenart_____/",
  instagramPravoslavni: "https://www.instagram.com/lenin_pravoslavni_kutak/",
  viber: "viber://chat?number=%2B381644905335",
};

export const WA_BASE = "https://wa.me/381644905335";

export function whatsappLink(message?: string) {
  const text =
    message ??
    "Zdravo Jelena, video/la sam vaše radove na LENART sajtu i želeo/la bih više informacija o slici po narudžbini.";
  return `${WA_BASE}?text=${encodeURIComponent(text)}`;
}

export type Category =
  | "Portreti"
  | "Priroda"
  | "Životinje"
  | "Savremeni motivi"
  | "Pravoslavni motivi";

export type Artwork = {
  id: string;
  title: string;
  category: Category;
  image: string;
  alt: string;
  technique?: string;
  dimensions?: string;
  description?: string;
  inquiryLabel: string;
  orientation: "portrait" | "landscape" | "square";
  featured?: boolean;
};

/**
 * Artwork data structure — new works can simply be appended here.
 * Set `featured: true` for the curated selection shown before "Pogledaj sve radove".
 */
export const ARTWORKS: Artwork[] = [
  {
    id: "oko-tigra",
    title: "Oko tigra",
    category: "Životinje",
    image: IMAGES.heroTigar,
    alt: "Jelena Raičević drži ručno slikanu sliku tigra",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "square",
    featured: true,
  },
  {
    id: "par-srce",
    title: "Rad po narudžbini",
    category: "Portreti",
    image: IMAGES.parSrce,
    alt: "Portret para naslikan na platnu u obliku srca sa zlatnim detaljima",
    inquiryLabel: "Naruči sličan rad",
    orientation: "portrait",
    featured: true,
  },
  {
    id: "selo",
    title: "Pejzaž",
    category: "Priroda",
    image: IMAGES.pejzaz,
    alt: "Umetnička slika seoskog pejzaža sa kamenom kućom Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
    featured: true,
  },
  {
    id: "pola-pola",
    title: "Pola pola",
    category: "Savremeni motivi",
    image: IMAGES.polaPola,
    alt: "Savremena umetnička slika ženskog lica u dva kolorita, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "landscape",
    featured: true,
  },
  {
    id: "sveti-nikola",
    title: "Sveti Nikola",
    category: "Pravoslavni motivi",
    image: IMAGES.svetiNikola,
    alt: "Umetnička slika Svetog Nikole Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "square",
    featured: true,
  },
  {
    id: "usne",
    title: "Savremeni motiv",
    category: "Savremeni motivi",
    image: IMAGES.usne,
    alt: "Jelena Raičević drži savremenu sliku crvenih usana na crnoj podlozi",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "square",
    featured: true,
  },
  {
    id: "vaza",
    title: "Vaza",
    category: "Savremeni motivi",
    image: IMAGES.atelje,
    alt: "Slika vaze sa cvećem na crvenoj podlozi u ateljeu Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "square",
    featured: true,
  },
  {
    id: "gospod-pred-zemljom",
    title: "Gospod pred zemljom",
    category: "Pravoslavni motivi",
    image: IMAGES.gospodPredZemljom,
    alt: "Umetnička slika „Gospod pred zemljom” Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
    featured: true,
  },
  {
    id: "sveta-petka",
    title: "Sveta Petka",
    category: "Pravoslavni motivi",
    image: IMAGES.svetaPetka,
    alt: "Umetnička slika Svete Petke Jelene Raičević u pozlaćenom ramu",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
  },
  {
    id: "isus-hrist",
    title: "Pravoslavni motiv",
    category: "Pravoslavni motivi",
    image: IMAGES.isusHrist,
    alt: "Uramljena umetnička slika Gospoda Isusa Hrista Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "square",
  },
  {
    id: "novak-djokovic",
    title: "Novak Đoković",
    category: "Portreti",
    image: IMAGES.novakDjokovic,
    alt: "Portret Novaka Đokovića na plavoj pozadini, rad Jelene Raičević",
    inquiryLabel: "Naruči sličan portret",
    orientation: "portrait",
    featured: true,
  },
  {
    id: "mlada",
    title: "Mlada",
    category: "Portreti",
    image: IMAGES.mlada,
    alt: "Slika mlade u venčanici sa leđa, u pozlaćenom ramu, rad Jelene Raičević",
    inquiryLabel: "Naruči sličan rad",
    orientation: "portrait",
  },
  {
    id: "patrijarh-pavle",
    title: "Patrijarh Pavle",
    category: "Portreti",
    image: IMAGES.patrijarhPavle,
    alt: "Portret patrijarha Pavla u zlatnom ramu, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
  },
  {
    id: "reci",
    title: "Reči",
    category: "Savremeni motivi",
    image: IMAGES.reci,
    alt: "Savremena slika dečaka okruženog crvenim i plavim rečima, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
    featured: true,
  },
  {
    id: "ruza",
    title: "Ruža",
    category: "Priroda",
    image: IMAGES.ruza,
    alt: "Slika crvene ruže na crnoj pozadini u drvenom ramu, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "landscape",
  },
  {
    id: "gospod-pruza-ruku",
    title: "Gospod pruža ruku",
    category: "Pravoslavni motivi",
    image: IMAGES.gospodPruzaRuku,
    alt: "Slika Gospoda koji pruža ruku čoveku u uzburkanom moru, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
  },
  {
    id: "osvetljen-put",
    title: "Osvetljen put",
    category: "Pravoslavni motivi",
    image: IMAGES.osvetljenPut,
    alt: "Slika osvetljenog puta sa dve figure, u pozlaćenom ramu, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
  },
  {
    id: "sveti-vasilije",
    title: "Sveti Vasilije Ostroški",
    category: "Pravoslavni motivi",
    image: IMAGES.svetiVasilije,
    alt: "Ikona Svetog Vasilija Ostroškog u drvenom ramu, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
  },
  {
    id: "sveta-petka-ikona",
    title: "Sveta Petka — ikona",
    category: "Pravoslavni motivi",
    image: IMAGES.svetaPetkaIkona,
    alt: "Ikona Svete Petke u belom ramu na plavoj podlozi, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "landscape",
  },
  {
    id: "tamjan",
    title: "Tamjan",
    category: "Pravoslavni motivi",
    image: IMAGES.tamjan,
    alt: "Slika kadionice sa tamjanom na crnoj pozadini u pozlaćenom ramu, rad Jelene Raičević",
    inquiryLabel: "Pitaj za dostupnost",
    orientation: "portrait",
  },
];

export const CATEGORIES = [
  "Sve",
  "Portreti",
  "Priroda",
  "Životinje",
  "Savremeni motivi",
  "Pravoslavni motivi",
] as const;

type GtagWindow = Window & { gtag?: (...args: unknown[]) => void };

export function track(event: string, params?: Record<string, unknown>) {
  if (typeof window === "undefined") return;
  (window as GtagWindow).gtag?.("event", event, params ?? {});
}
