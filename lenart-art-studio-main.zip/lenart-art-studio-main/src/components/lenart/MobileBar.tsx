import { useEffect, useState } from "react";
import { CONTACT, track, whatsappLink } from "@/lib/lenart";

export function MobileBar() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > window.innerHeight * 0.85);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 backdrop-blur-md transition-transform duration-300 lg:inset-x-auto lg:right-6 lg:bottom-6 lg:rounded-[8px] lg:border lg:shadow-lg ${
        show ? "translate-y-0" : "translate-y-full"
      }`}
    >
      <div className="grid grid-cols-2 gap-3 px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] lg:min-w-[340px] lg:pb-3">
        <a
          href={CONTACT.instagram}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => track("instagram_click", { location: "mobile_bar" })}
          className="btn-base btn-primary w-full"
        >
          Instagram
        </a>
        <a
          href={whatsappLink()}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => track("whatsapp_click", { location: "mobile_bar" })}
          className="btn-base btn-outline w-full"
        >
          WhatsApp
        </a>
      </div>
    </div>
  );
}
