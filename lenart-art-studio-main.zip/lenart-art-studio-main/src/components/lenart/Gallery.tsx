import { useEffect, useMemo, useRef, useState } from "react";
import {
  ARTWORKS,
  CATEGORIES,
  CONTACT,
  track,
  whatsappLink,
  type Artwork,
} from "@/lib/lenart";
import { Reveal } from "./Reveal";

function inquiryText(a: Artwork) {
  return `Zdravo Jelena, video/la sam rad „${a.title}” (${a.category}) na LENART sajtu i zanima me više informacija.`;
}

export function Gallery() {
  const [filter, setFilter] = useState<string>("Sve");
  const [expanded, setExpanded] = useState(false);
  const [active, setActive] = useState<Artwork | null>(null);

  const filtered = useMemo(
    () => (filter === "Sve" ? ARTWORKS : ARTWORKS.filter((a) => a.category === filter)),
    [filter],
  );
  const editorial = filter === "Sve" && !expanded;
  const visible = expanded ? filtered : filtered.filter((a) => a.featured);
  const hasMore = !expanded && filtered.length > visible.length;

  return (
    <section id="radovi" className="py-[clamp(64px,8vw,120px)]">
      <div className="container-lenart">
        <Reveal className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="eyebrow">GALERIJA</p>
            <h2 className="h2-display mt-4">Odabrani radovi</h2>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground">
              Originalne ručno rađene slike nastale u Novom Sadu — od portreta i pejzaža do
              savremenih i pravoslavnih motiva.
            </p>
          </div>
        </Reveal>

        <div
          className="mt-10 flex flex-wrap gap-2 border-b border-border pb-6"
          role="group"
          aria-label="Filtriranje radova po kategoriji"
        >
          {CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              aria-pressed={filter === c}
              onClick={() => {
                setFilter(c);
                setExpanded(false);
              }}
              className={`min-h-11 rounded-full px-5 text-sm font-medium transition-colors ${
                filter === c
                  ? "bg-primary text-primary-foreground"
                  : "border border-border text-muted-foreground hover:border-primary hover:text-primary"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <ul className="mt-12 grid grid-cols-2 gap-x-6 gap-y-12 lg:grid-cols-12">
          {visible.map((a, i) => {
            const wide = editorial && a.orientation === "landscape";
            return (
              <li key={a.id} className={wide ? "col-span-2 lg:col-span-8" : "lg:col-span-4"}>
                <Reveal delay={(i % 3) * 80}>
                  <button
                    type="button"
                    className="group block w-full text-left"
                    onClick={() => {
                      setActive(a);
                      track("gallery_lightbox_open", { artwork: a.title, category: a.category });
                    }}
                  >
                    <span className="relative block overflow-hidden rounded-[8px] border border-border bg-card">
                      <img
                        src={a.image}
                        alt={a.alt}
                        loading="lazy"
                        decoding="async"
                        width={1200}
                        height={1400}
                        className={`w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.02] ${
                          wide ? "aspect-[4/5] lg:aspect-[16/10]" : "aspect-[4/5]"
                        }`}
                      />
                      <span className="pointer-events-none absolute inset-0 bg-foreground/0 transition-colors duration-300 group-hover:bg-foreground/8" />
                    </span>
                    <span className="mt-4 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                      <span className="font-serif text-xl sm:text-2xl">{a.title}</span>
                      <span className="text-[0.7rem] tracking-[0.16em] text-muted-foreground uppercase">
                        {a.category}
                      </span>
                    </span>
                    <span className="mt-1.5 block text-sm text-primary underline-offset-4 group-hover:underline">
                      {a.inquiryLabel} →
                    </span>
                  </button>
                </Reveal>
              </li>
            );
          })}
        </ul>

        {hasMore && (
          <div className="mt-16 text-center">
            <button
              type="button"
              className="btn-base btn-outline"
              onClick={() => setExpanded(true)}
            >
              Pogledaj sve radove
            </button>
          </div>
        )}
      </div>


      {active && <Lightbox artwork={active} onClose={() => setActive(null)} />}
    </section>
  );
}

function Lightbox({ artwork, onClose }: { artwork: Artwork; onClose: () => void }) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    closeRef.current?.focus();
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab" && panelRef.current) {
        const items = panelRef.current.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled])',
        );
        if (!items.length) return;
        const first = items[0]!;
        const last = items[items.length - 1]!;
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/70 p-4 backdrop-blur-sm sm:p-8"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={`${artwork.title} — ${artwork.category}`}
        className="max-h-full w-full max-w-5xl overflow-y-auto rounded-[14px] bg-background p-4 sm:p-6"
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="eyebrow">{artwork.category}</p>
            <h3 className="h3-display mt-2">{artwork.title}</h3>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Zatvori prikaz rada"
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-border text-lg"
          >
            ✕
          </button>
        </div>

        <img
          src={artwork.image}
          alt={artwork.alt}
          className="mt-5 max-h-[62vh] w-full rounded-[10px] object-contain"
        />

        {artwork.description && (
          <p className="mt-5 max-w-2xl text-muted-foreground">{artwork.description}</p>
        )}

        <div className="mt-6 flex flex-wrap gap-3">
          <a
            href={CONTACT.instagram}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => {
              track("artwork_inquiry_click", {
                artwork: artwork.title,
                category: artwork.category,
                channel: "instagram",
              });
              track("instagram_click", { location: "lightbox" });
            }}
            className="btn-base btn-primary"
          >
            Pitaj za ovaj rad
          </a>
          <a
            href={whatsappLink(inquiryText(artwork))}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => {
              track("artwork_inquiry_click", {
                artwork: artwork.title,
                category: artwork.category,
                channel: "whatsapp",
              });
              track("whatsapp_click", { location: "lightbox" });
            }}
            className="btn-base btn-outline"
          >
            WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}
