import { useEffect, useState } from "react";
import { CONTACT, IMAGES, track } from "@/lib/lenart";


const NAV = [
  { href: "#radovi", label: "Radovi" },
  { href: "#po-narudzbini", label: "Po narudžbini" },
  { href: "#pravoslavni-motivi", label: "Pravoslavni motivi" },
  { href: "#o-jeleni", label: "O Jeleni" },
  { href: "#kontakt", label: "Kontakt" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "border-b border-border bg-card/90 backdrop-blur-md"
          : "border-b border-transparent"
      }`}
    >
      <div className="container-lenart flex h-[86px] items-center justify-between gap-6">
        <a
          href="#top"
          className="flex min-w-0 items-center gap-3"
          aria-label="LENART — početak strane"
        >
          <img
            src={IMAGES.logo}
            alt="LENART logo"
            width={120}
            height={200}
            className="h-[40px] w-auto shrink-0 sm:h-[50px]"
          />
          <span className="min-w-0 leading-none">
            <span className="block font-serif text-[1.6rem] font-semibold tracking-[0.24em] sm:text-[1.85rem]">
              LENART
            </span>
            <span className="mt-1 hidden text-[0.68rem] tracking-[0.18em] text-muted-foreground uppercase sm:block">
              Jelena Raičević
            </span>
          </span>
        </a>


        <nav aria-label="Glavna navigacija" className="hidden items-center gap-8 lg:flex">
          {NAV.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="relative text-sm text-foreground/85 transition-colors hover:text-primary after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="hidden lg:block">
          <a
            href={CONTACT.instagram}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => track("commission_cta_click", { location: "header" })}
            className="btn-base btn-primary"
          >
            Naruči sliku
          </a>
        </div>

        <button
          type="button"
          className="-mr-2 grid h-11 w-11 shrink-0 place-items-center lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Zatvori meni" : "Otvori meni"}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="relative block h-4 w-6">
            <span
              className={`absolute left-0 block h-px w-6 bg-foreground transition-transform duration-300 ${open ? "top-2 rotate-45" : "top-0"}`}
            />
            <span
              className={`absolute top-2 left-0 block h-px w-6 bg-foreground transition-opacity duration-200 ${open ? "opacity-0" : "opacity-100"}`}
            />
            <span
              className={`absolute left-0 block h-px w-6 bg-foreground transition-transform duration-300 ${open ? "top-2 -rotate-45" : "top-4"}`}
            />
          </span>
        </button>
      </div>

      {open && (
        <div
          id="mobile-menu"
          className="fixed inset-0 top-[86px] z-40 flex flex-col gap-2 overflow-y-auto bg-background px-6 pt-8 pb-16 lg:hidden"
        >
          {NAV.map((n) => (
            <a
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className="border-b border-border py-4 font-serif text-2xl"
            >
              {n.label}
            </a>
          ))}
          <a
            href={CONTACT.instagram}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => {
              track("commission_cta_click", { location: "mobile_menu" });
              setOpen(false);
            }}
            className="btn-base btn-primary mt-8 w-full"
          >
            Naruči sliku
          </a>
          <a href={CONTACT.tel} className="mt-4 text-center text-sm text-muted-foreground">
            {CONTACT.phoneDisplay}
          </a>
        </div>
      )}
    </header>
  );
}
