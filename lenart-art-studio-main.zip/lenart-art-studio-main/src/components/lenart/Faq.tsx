import { useState } from "react";

export const FAQ_ITEMS = [
  {
    q: "Da li izrađujete slike po narudžbini?",
    a: "Da. Jelena može da radi prema fotografiji, određenom motivu ili ideji koju zajedno definišete.",
  },
  {
    q: "Koliko traje izrada slike?",
    a: "Izrada traje do približno 14 dana, u zavisnosti od motiva, dimenzije i trenutnog broja narudžbina.",
  },
  {
    q: "Koje motive Jelena slika?",
    a: "Portrete, prirodu i pejzaže, životinje, savremene motive, pravoslavne motive i druge radove prema želji naručioca.",
  },
  {
    q: "Koliko košta slika po narudžbini?",
    a: "Cena zavisi od dimenzije, tehnike i zahtevnosti rada. Procena se dobija nakon dogovora o željenoj slici.",
  },
  {
    q: "Da li šaljete slike van Srbije?",
    a: "Da. LENART radovi mogu se poslati kupcima u Srbiji i inostranstvu. Detalji i troškovi dostave dogovaraju se u zavisnosti od destinacije i dimenzija rada.",
  },
  {
    q: "Da li izrađujete pravoslavne ikone?",
    a: "Jelena izrađuje umetničke slike svetitelja i druge radove inspirisane pravoslavnim motivima. Ne radi se o tradicionalnom kanonskom ikonopisu.",
  },
];


export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <dl className="border-t border-border">
      {FAQ_ITEMS.map((item, i) => {
        const isOpen = open === i;
        return (
          <div key={item.q} className="border-b border-border">
            <dt>
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={`faq-panel-${i}`}
                id={`faq-button-${i}`}
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex w-full items-center justify-between gap-6 py-6 text-left"
              >
                <span className="font-serif text-xl sm:text-2xl">{item.q}</span>
                <span
                  aria-hidden="true"
                  className={`relative grid h-9 w-9 shrink-0 place-items-center rounded-full border border-border text-primary transition-transform duration-300 ${isOpen ? "rotate-45" : ""}`}
                >
                  <span className="absolute h-px w-3.5 bg-current" />
                  <span className="absolute h-3.5 w-px bg-current" />
                </span>
              </button>
            </dt>
            <dd
              id={`faq-panel-${i}`}
              aria-labelledby={`faq-button-${i}`}
              className={`grid transition-all duration-300 ease-out ${isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}
            >
              <div className="overflow-hidden">
                <p className="max-w-2xl pb-6 text-[1.02rem] leading-relaxed text-muted-foreground">
                  {item.a}
                </p>
              </div>
            </dd>
          </div>
        );
      })}
    </dl>
  );
}
