import { createFileRoute } from "@tanstack/react-router";
import { CONTACT, IMAGES, track, whatsappLink } from "@/lib/lenart";
import { Header } from "@/components/lenart/Header";
import { MobileBar } from "@/components/lenart/MobileBar";
import { Gallery } from "@/components/lenart/Gallery";
import { Faq, FAQ_ITEMS } from "@/components/lenart/Faq";
import { Reveal } from "@/components/lenart/Reveal";

const TITLE = "Slike po narudžbini Novi Sad | LENART – Jelena Raičević";
const DESC =
  "Originalne ručno rađene slike i slike po narudžbini Jelene Raičević. Portreti, pejzaži, pravoslavni i savremeni motivi. Novi Sad, dostava širom sveta.";
const OG_TITLE = "LENART | Originalne slike i slike po narudžbini";
const OG_DESC =
  "Umetnički radovi Jelene Raičević iz Novog Sada — originalne slike i slike po vašoj ideji.";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: OG_TITLE },
      { property: "og:description", content: OG_DESC },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { property: "og:locale", content: "sr_RS" },
      { property: "og:image", content: IMAGES.heroTigar },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: OG_TITLE },
      { name: "twitter:description", content: OG_DESC },
      { name: "twitter:image", content: IMAGES.heroTigar },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify([
          {
            "@context": "https://schema.org",
            "@type": "WebSite",
            name: "LENART",
            inLanguage: "sr-Latn",
            description: DESC,
          },
          {
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: TITLE,
            description: DESC,
            inLanguage: "sr-Latn",
          },
          {
            "@context": "https://schema.org",
            "@type": "Person",
            name: "Jelena Raičević",
            jobTitle: "Umetnica",
            brand: { "@type": "Brand", name: "LENART" },
            homeLocation: {
              "@type": "Place",
              address: {
                "@type": "PostalAddress",
                addressLocality: "Novi Sad",
                addressCountry: "RS",
              },
            },
            email: CONTACT.email,
            telephone: "+381644905335",
            sameAs: [CONTACT.instagram, CONTACT.instagramPravoslavni],
          },
          {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: FAQ_ITEMS.map((f) => ({
              "@type": "Question",
              name: f.q,
              acceptedAnswer: { "@type": "Answer", text: f.a },
            })),
          },
        ]),
      },
    ],
  }),
});

function LineIcon({ d, className }: { d: string; className?: string }) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.25"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className ?? "h-6 w-6 shrink-0 text-primary"}
    >
      <path d={d} />
    </svg>
  );
}


const ICON_BRUSH = "M4 20c3 0 4-1.5 4-4M8 16 18.5 5.5a2.1 2.1 0 0 1 3 3L11 19";
const ICON_STAR = "m12 3 2.4 5.3 5.6.6-4.2 3.9 1.2 5.7L12 15.6 6.9 18.5l1.2-5.7L4 8.9l5.6-.6z";
const ICON_GLOBE = "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 2.7 3.8 5.7 3.8 9S14.5 21 12 21s-3.8-2.7-3.8-9S9.5 3 12 3z";
const ICON_HAND = "M12 21c-4-2.5-7-5.5-7-9a3.4 3.4 0 0 1 7-1.4A3.4 3.4 0 0 1 19 12c0 3.5-3 6.5-7 9z";
const ICON_HOME = "M4 10.5 12 4l8 6.5V20H4z";
const ICON_MOTIV = "M12 3c-3.5 2.8-6 6-6 9.5a6 6 0 0 0 12 0C18 9 15.5 5.8 12 3z";
const ICON_SUBSTRATE = "M4 5h16v14H4zM8 5v14M16 5v14";
const ICON_EXPRESSION = "M12 3l2.4 5.3 5.6.6-4.2 3.9 1.2 5.7L12 15.6l-5.1 2.9 1.2-5.7L4 8.9l5.6-.6z";
const ICON_FORMAT = "M4 7h16M4 12h10M4 17h16";

function Index() {
  return (
    <div id="top" className="overflow-x-hidden">
      <Header />
      <MobileBar />

      <main>
        {/* HERO */}
        <section className="pt-[136px] pb-[clamp(56px,7vw,104px)]">
          <div className="container-lenart grid items-center gap-8 md:grid-cols-[minmax(0,45fr)_minmax(0,55fr)] md:gap-10 lg:gap-[72px]">
            <div className="order-1">
              <p className="eyebrow">ORIGINALNE SLIKE I SLIKE PO NARUDŽBINI · NOVI SAD</p>
              <h1 className="mt-6 font-serif text-[clamp(2.75rem,5vw,4.5rem)] leading-[1.02] font-semibold tracking-[-0.01em] md:text-[clamp(2.55rem,5vw,4.5rem)]">
                <span className="block whitespace-nowrap">Vaša ideja.</span>
                <span className="block whitespace-nowrap">Jelenina umetnost.</span>
              </h1>
              <img
                src={IMAGES.heroTigar}
                alt="Jelena Raičević drži ručno slikanu sliku tigra"
                width={1440}
                height={1440}
                fetchPriority="high"
                decoding="async"
                className="mt-8 w-full rounded-[10px] border border-border object-cover md:hidden"
              />
              <p className="mt-6 max-w-xl text-[1.15rem] leading-[1.7] text-muted-foreground">
                Otkrijte originalne ručno rađene slike Jelene Raičević ili pretvorite svoju
                fotografiju, uspomenu i ideju u jedinstveno umetničko delo.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a href="#radovi" className="btn-base btn-primary">
                  Pogledaj radove
                </a>
                <a
                  href={CONTACT.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    track("commission_cta_click", { location: "hero" });
                    track("instagram_click", { location: "hero" });
                  }}
                  className="btn-base btn-outline"
                >
                  Naruči svoju sliku
                </a>
              </div>

              <ul className="mt-7 grid grid-cols-3 items-start gap-2 text-[0.62rem] sm:flex sm:gap-x-6 sm:text-[0.7rem]">
                {[
                  [ICON_BRUSH, "Ručno izrađeno"],
                  [ICON_STAR, "Jedinstveni radovi"],
                  [ICON_GLOBE, "Dostava širom sveta"],
                ].map(([d, label]: string[]) => (
                  <li
                    key={label!}
                    className="flex min-w-0 flex-col items-start gap-1.5 text-foreground/90 sm:min-w-[92px]"
                  >
                    <LineIcon d={d!} className="h-5 w-5 shrink-0 text-primary" />
                    <span className="leading-tight tracking-[0.05em]">{label}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="order-2 hidden md:block">
              <img
                src={IMAGES.heroTigar}
                alt="Jelena Raičević drži ručno slikanu sliku tigra"
                width={1440}
                height={1440}
                fetchPriority="high"
                decoding="async"
                className="w-full rounded-[10px] border border-border object-cover"
              />
            </div>

          </div>
        </section>

        {/* BRAND STATEMENT */}
        <section className="border-y border-border bg-card py-[clamp(48px,6vw,84px)]">
          <div className="container-lenart">
            <Reveal className="mx-auto max-w-3xl text-center">
              <h2 className="h2-display">Umetnost koja unosi toplinu u prostor.</h2>
              <p className="mx-auto mt-6 max-w-2xl text-[1.1rem] leading-[1.75] text-muted-foreground">
                Svaka slika nastaje iz nadahnuća i želje da prenese emociju, priču i energiju
                prostora u kome će živeti. Jelena stvara sa željom da njena dela unesu ljubav,
                sreću i toplinu u vaš dom.
              </p>
              <svg
                aria-hidden="true"
                viewBox="0 0 120 24"
                className="mx-auto mt-8 h-6 w-32 text-gold"
                fill="none"
                stroke="currentColor"
                strokeWidth="1"
              >
                <path d="M0 12h44" />
                <path d="M76 12h44" />
                <path d="M60 18c-4-2.6-7-5-7-7.6A3 3 0 0 1 60 8.7 3 3 0 0 1 67 10.4c0 2.6-3 5-7 7.6z" />
              </svg>
            </Reveal>
          </div>
        </section>

        <Gallery />

        {/* COMMISSION */}
        <section
          id="po-narudzbini"
          className="border-y border-border bg-card py-[clamp(64px,8vw,120px)]"
        >
          <div className="container-lenart">
            <div className="grid gap-12 lg:grid-cols-[minmax(0,47fr)_minmax(0,53fr)] lg:items-center lg:gap-[72px]">
              <Reveal className="relative">
                <div
                  aria-hidden="true"
                  className="absolute -top-5 -left-5 hidden h-24 w-24 border-t border-l border-gold/70 lg:block"
                />
                <img
                  src={IMAGES.usne}
                  alt="Jelena Raičević sa savremenom slikom crvenih usana na crnoj podlozi"
                  loading="lazy"
                  decoding="async"
                  width={1440}
                  height={1440}
                  className="w-full rounded-[10px] border border-border object-cover"
                />
                <p className="mt-4 flex items-center gap-3 text-sm tracking-[0.14em] text-muted-foreground uppercase">
                  <span aria-hidden="true" className="h-px w-8 bg-gold" />
                  Savremeni motiv · rad iz ateljea
                </p>
              </Reveal>

              <Reveal>
                <p className="eyebrow">SLIKE PO VAŠOJ IDEJI</p>
                <h2 className="h2-display mt-5">Od uspomene do originalne slike.</h2>
                <p className="mt-6 max-w-xl text-[1.08rem] leading-[1.75] text-muted-foreground">
                  Portret drage osobe, kućni ljubimac, omiljeni pejzaž, porodična uspomena,
                  pravoslavni motiv ili potpuno vaša zamisao — Jelena izrađuje slike po narudžbini
                  prema ideji koju joj pošaljete.
                </p>
                <p className="mt-6 inline-block border-l-2 border-gold pl-4 font-serif text-[1.35rem] leading-snug">
                  Izrada od nedelju dana do mesec–dva,
                  <br />
                  u zavisnosti od zahteva klijenta.
                </p>

                <div className="mt-8 flex flex-wrap gap-3">
                  <a
                    href={CONTACT.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      track("commission_cta_click", { location: "commission" });
                      track("instagram_click", { location: "commission" });
                    }}
                    className="btn-base btn-primary"
                  >
                    Pošalji svoju ideju
                  </a>
                  <a
                    href={whatsappLink()}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => track("whatsapp_click", { location: "commission" })}
                    className="btn-base btn-outline"
                  >
                    WhatsApp
                  </a>
                  <a
                    href={CONTACT.viber}
                    onClick={() => track("viber_click", { location: "commission" })}
                    className="btn-base btn-outline"
                  >
                    Viber
                  </a>
                </div>
              </Reveal>
            </div>

            <Reveal className="mt-[clamp(48px,6vw,80px)]">
              <div className="flex items-center gap-5">
                <p className="eyebrow shrink-0">KAKO NASTAJE VAŠA SLIKA</p>
                <span aria-hidden="true" className="h-px w-full bg-gold/50" />
              </div>

              <ol className="relative mt-12 grid gap-x-10 gap-y-12 md:grid-cols-2 lg:grid-cols-4 lg:gap-8">
                {[
                  [
                    "01",
                    "Pošaljite ideju",
                    "Pošaljite fotografiju, motiv ili opišite šta zamišljate.",
                  ],
                  ["02", "Dogovorite detalje", "Dogovaraju se format, tehnika, izgled rada i cena."],
                  ["03", "Slika nastaje", "Jelena ručno izrađuje vaš jedinstveni rad."],
                  [
                    "04",
                    "Preuzimanje / dostava",
                    "Lično preuzimanje u Novom Sadu ili dostava širom sveta.",
                  ],
                ].map(([n, t, d]: string[], index) => (
                  <li key={n!} className="group relative pl-12 md:pt-12 md:pl-0">
                    <span
                      aria-hidden="true"
                      className="absolute top-1 left-0 h-full w-px bg-gold/50 md:hidden"
                    />
                    {index < 3 && (
                      <span
                        aria-hidden="true"
                        className={`absolute top-[13px] left-[13px] hidden h-px bg-gold/60 md:block ${index === 1 ? "md:hidden lg:block" : "right-[-40px] lg:right-[-32px]"}`}
                      />
                    )}
                    <span className="absolute top-1 left-0 z-10 grid h-[26px] w-[26px] -translate-x-1/2 place-items-center rounded-full border border-gold bg-card text-[0.7rem] font-semibold text-primary transition-all duration-300 group-hover:scale-110 group-hover:bg-gold md:top-0 md:translate-x-0">
                      {n}
                    </span>
                    <h3 className="font-serif text-[1.4rem] transition-colors duration-300 group-hover:text-primary">
                      {t}
                    </h3>
                    <p className="mt-2.5 max-w-xs text-[0.95rem] leading-relaxed text-muted-foreground">
                      {d}
                    </p>
                  </li>
                ))}
              </ol>
            </Reveal>
          </div>
        </section>

        {/* TECHNIQUES */}
        <section className="relative overflow-hidden py-[clamp(72px,9vw,128px)]">
          <img
            src={IMAGES.atelje}
            alt=""
            aria-hidden="true"
            loading="lazy"
            decoding="async"
            className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-[0.16]"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-background/90"
          />
          <div className="container-lenart relative">
            <div className="grid items-stretch gap-12 lg:grid-cols-2 lg:gap-16">
              <Reveal className="flex flex-col justify-center">
                <p className="eyebrow">PRISTUP RADU</p>
                <h2 className="h2-display mt-5">
                  Različite tehnike.
                  <br />
                  Jedinstven rukopis.
                </h2>
                <p className="mt-7 max-w-lg text-[1.1rem] leading-[1.8] text-muted-foreground">
                  Jelena u svom radu koristi različite slikarske tehnike, birajući pristup u skladu
                  sa motivom, podlogom i željenim umetničkim izrazom.
                </p>
                <p className="mt-8 max-w-lg border-l-2 border-primary pl-5 font-serif text-[1.5rem] leading-snug italic text-foreground">
                  Tehnika se bira prema slici — nikada slika prema tehnici.
                </p>
              </Reveal>

              <Reveal className="h-full">
                <ul className="grid h-full grid-cols-1 gap-4 sm:grid-cols-2 sm:grid-rows-2">
                  {[
                    ["Motiv", "Od portreta i pejzaža do savremenih i pravoslavnih motiva.", ICON_MOTIV],
                    ["Podloga", "Platno, drvo ili format prilagođen prostoru.", ICON_SUBSTRATE],
                    ["Izraz", "Kolorit i potez koji odgovaraju priči rada.", ICON_EXPRESSION],
                    ["Format", "Dimenzije se dogovaraju za svaki rad posebno.", ICON_FORMAT],
                  ].map(([t, d, icon]: string[]) => (
                    <li
                      key={t!}
                      className="group relative flex h-full flex-col justify-between overflow-hidden rounded-[10px] border border-border bg-card/70 p-5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:border-gold hover:bg-card/90 hover:shadow-lg sm:p-6"
                    >
                      <div>
                        <LineIcon
                          d={icon!}
                          className="h-5 w-5 text-primary transition-transform duration-300 group-hover:scale-110"
                        />
                        <p className="mt-4 font-serif text-[1.2rem]">{t}</p>
                        <p className="mt-2 text-[0.93rem] leading-relaxed text-muted-foreground">{d}</p>
                      </div>
                      <span
                        aria-hidden="true"
                        className="absolute bottom-0 left-0 h-[2px] w-0 bg-gold transition-all duration-300 group-hover:w-full"
                      />
                    </li>
                  ))}
                </ul>
              </Reveal>
            </div>
          </div>
        </section>


        {/* ORTHODOX */}
        <section
          id="pravoslavni-motivi"
          className="border-y border-border bg-sand py-[clamp(64px,8vw,120px)]"
        >
          <div className="container-lenart">
            <Reveal className="max-w-2xl">
              <p className="eyebrow">POSEBNA KOLEKCIJA</p>
              <h2 className="h2-display mt-5">Pravoslavne slike i motivi svetitelja</h2>
              <p className="mt-6 text-[1.08rem] leading-[1.75] text-muted-foreground">
                Posebno mesto u Jeleninom stvaralaštvu imaju umetničke slike inspirisane
                pravoslavnom verom, svetiteljima i duhovnim motivima. Radovi nastaju ručno na
                platnu ili papiru, kao postojeća dela ili po dogovoru prema željenom motivu.
              </p>
            </Reveal>

            <div className="mt-12 grid gap-8 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
              <Reveal>
                <figure>
                  <img
                    src={IMAGES.svetiNikola}
                    alt="Umetnička slika Svetog Nikole Jelene Raičević"
                    loading="lazy"
                    decoding="async"
                    width={1440}
                    height={1440}
                    className="w-full rounded-[10px] border border-border object-cover"
                  />
                  <figcaption className="mt-3 text-sm text-muted-foreground">
                    Sveti Nikola — umetnička slika na platnu
                  </figcaption>
                </figure>
              </Reveal>
              <Reveal delay={100}>
                <figure>
                  <img
                    src={IMAGES.svetaPetka}
                    alt="Umetnička slika Svete Petke Jelene Raičević u pozlaćenom ramu"
                    loading="lazy"
                    decoding="async"
                    width={1280}
                    height={1600}
                    className="h-full w-full rounded-[10px] border border-border object-cover"
                  />
                  <figcaption className="mt-3 text-sm text-muted-foreground">
                    Umetničke slike inspirisane pravoslavnim motivima — ne radi se o tradicionalnom
                    kanonskom ikonopisu.
                  </figcaption>
                </figure>
              </Reveal>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-3">
              <a
                href="#radovi"
                onClick={() => track("orthodox_collection_click", { target: "gallery" })}
                className="btn-base btn-primary"
              >
                Pogledaj radove
              </a>
              <a
                href={CONTACT.instagram}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  track("orthodox_collection_click", { target: "instagram" });
                  track("instagram_click", { location: "orthodox" });
                }}
                className="btn-base btn-outline"
              >
                Naruči motiv
              </a>
            </div>
            <p className="mt-6 text-sm">
              <a
                href={CONTACT.instagramPravoslavni}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => track("instagram_click", { location: "orthodox_secondary" })}
                className="text-primary underline underline-offset-4"
              >
                Pratite i Lenin pravoslavni kutak na Instagramu
              </a>
            </p>
          </div>
        </section>

        {/* ABOUT */}
        <section id="o-jeleni" className="py-[clamp(64px,8vw,120px)]">
          <div className="container-lenart grid gap-12 lg:grid-cols-2 lg:items-center lg:gap-[72px]">
            <Reveal>
              <img
                src={IMAGES.oMeni}
                alt="Jelena Raičević u svom umetničkom prostoru"
                loading="lazy"
                decoding="async"
                width={1153}
                height={1440}
                className="w-full rounded-[10px] border border-border object-cover"
              />
            </Reveal>
            <Reveal>
              <p className="eyebrow">IZA LENART-A</p>
              <h2 className="h2-display mt-5">Jelena Raičević</h2>
              <div className="mt-6 space-y-5 text-[1.08rem] leading-[1.75] text-muted-foreground">
                <p>
                  Jelena Raičević je samouka umetnica iz Novog Sada i osnivač brenda LENART —
                  imena nastalog spajanjem Jelena i ART.
                </p>
                <p>
                  Slikanjem se bavi od malena, a kroz svoj rad istražuje različite motive, tehnike
                  i načine umetničkog izražavanja.
                </p>
                <p>
                  Inspiraciju pronalazi u ljudima, prirodi, veri, emocijama i svakodnevnim
                  trenucima. Slika iz nadahnuća, sa željom da njena dela ispune ljude ljubavlju i
                  srećom i unesu toplinu u njihov dom.
                </p>
              </div>
              <blockquote className="mt-9 border-l-2 border-gold pl-7 text-[1.7rem] leading-snug">
                „Želim da moje slike unesu ljubav, sreću i toplinu u dom.”
                <footer className="mt-3 font-sans text-sm tracking-wide text-muted-foreground">
                  — Jelena Raičević
                </footer>
              </blockquote>
            </Reveal>
          </div>
        </section>

        {/* WHY */}
        <section className="border-y border-border bg-card py-[clamp(56px,7vw,100px)]">
          <div className="container-lenart">
            <Reveal>
              <h2 className="h2-display">Zašto LENART</h2>
            </Reveal>
            <ul className="mt-12 grid gap-12 md:grid-cols-3 md:gap-0">
              {[
                ["Originalno", "Svaki rad nastaje ručno i nosi svoj karakter.", ICON_BRUSH],
                [
                  "Lično",
                  "Fotografija, uspomena ili ideja mogu postati jedinstveno umetničko delo.",
                  ICON_HAND,
                ],
                [
                  "Stvoreno za vaš prostor",
                  "Umetnost koja domu daje emociju, toplinu i priču.",
                  ICON_HOME,
                ],
              ].map(([t, d, icon]: string[], i) => (
                <Reveal key={t!} as="li" delay={i * 90}>
                  <div
                    className={`md:px-10 ${i > 0 ? "md:border-l md:border-border" : "md:pl-0"} ${i === 2 ? "md:pr-0" : ""}`}
                  >
                    <LineIcon d={icon!} />
                    <h3 className="h3-display mt-5">{t}</h3>
                    <p className="mt-3 max-w-sm leading-relaxed text-muted-foreground">{d}</p>
                  </div>
                </Reveal>
              ))}
            </ul>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-[clamp(64px,8vw,116px)]">
          <div className="container-lenart grid gap-10 lg:grid-cols-[minmax(0,33fr)_minmax(0,67fr)] lg:gap-20">
            <Reveal>
              <h2 className="h2-display">Najčešća pitanja</h2>
              <p className="mt-5 max-w-sm text-lg leading-relaxed text-muted-foreground">
                Sve što vas zanima pre nego što izaberete ili naručite svoju sliku.
              </p>
            </Reveal>
            <Reveal>
              <Faq />
            </Reveal>
          </div>
        </section>

        {/* FINAL CTA */}
        <section id="kontakt" className="relative isolate overflow-hidden">
          <img
            src={IMAGES.svetiNikola}
            alt=""
            aria-hidden="true"
            loading="lazy"
            decoding="async"
            className="absolute inset-0 -z-10 h-full w-full object-cover object-center"
          />
          <div className="absolute inset-0 -z-10 bg-[oklch(0.222_0.008_60/0.8)]" />
          <div className="container-lenart py-[clamp(72px,9vw,124px)]">
            <div className="max-w-2xl text-[oklch(0.964_0.008_85)]">
              <h2 className="h2-display">Koju biste priču vi pretvorili u sliku?</h2>
              <p className="mt-6 text-[1.08rem] leading-[1.75] opacity-90">
                Pošaljite Jeleni svoju fotografiju, motiv ili ideju i zajedno dogovorite kako bi
                vaš budući rad mogao da izgleda.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={CONTACT.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => track("instagram_click", { location: "final_cta" })}
                  className="btn-base btn-primary"
                >
                  Instagram
                </a>
                {[
                  ["WhatsApp", whatsappLink(), "whatsapp_click"],
                  ["Viber", CONTACT.viber, "viber_click"],
                  ["Poziv", CONTACT.tel, "phone_click"],
                  ["Email", CONTACT.mailto, "email_click"],
                ].map(([label, href, ev]: string[]) => (
                  <a
                    key={label!}
                    href={href!}
                    onClick={() => track(ev!, { location: "final_cta" })}
                    className="btn-base border border-[oklch(0.964_0.008_85/0.5)] text-[oklch(0.964_0.008_85)] transition-colors hover:bg-[oklch(0.964_0.008_85/0.12)]"
                  >
                    {label}
                  </a>
                ))}
              </div>

              <div className="mt-9 space-y-1 text-lg">
                <p>
                  <a href={CONTACT.tel} className="underline-offset-4 hover:underline">
                    {CONTACT.phoneDisplay}
                  </a>
                </p>
                <p>
                  <a href={CONTACT.mailto} className="underline-offset-4 hover:underline">
                    {CONTACT.email}
                  </a>
                </p>
              </div>
              <p className="mt-6 text-sm tracking-[0.16em] uppercase opacity-80">
                Novi Sad · Dostava širom sveta
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-card pt-16 pb-28 lg:pb-16">
        <div className="container-lenart grid gap-12 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <div className="flex items-center gap-3">
              <img
                src={IMAGES.logo}
                alt="LENART logo"
                loading="lazy"
                width={120}
                height={200}
                className="h-[48px] w-auto"
              />
              <span className="font-serif text-2xl tracking-[0.24em]">LENART</span>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">Jelena Raičević</p>
            <p className="mt-5 max-w-xs font-serif text-lg">
              Umetnost koja unosi toplinu u dom.
            </p>
          </div>

          <nav aria-label="Navigacija u podnožju" className="text-[0.95rem]">
            <ul className="space-y-3">
              {[
                ["#radovi", "Radovi"],
                ["#po-narudzbini", "Po narudžbini"],
                ["#pravoslavni-motivi", "Pravoslavni motivi"],
                ["#o-jeleni", "O Jeleni"],
                ["#kontakt", "Kontakt"],
              ].map(([href, label]: string[]) => (
                <li key={href!}>
                  <a href={href!} className="hover:text-primary">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Kontakt" className="text-[0.95rem]">
            <ul className="space-y-3">
              <li>
                <a href={CONTACT.tel} className="hover:text-primary">
                  {CONTACT.phoneDisplay}
                </a>
              </li>
              <li>
                <a href={CONTACT.mailto} className="break-all hover:text-primary">
                  {CONTACT.email}
                </a>
              </li>
              <li>
                <a
                  href={CONTACT.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => track("instagram_click", { location: "footer" })}
                  className="hover:text-primary"
                >
                  Instagram
                </a>
              </li>
              <li>
                <a
                  href={whatsappLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => track("whatsapp_click", { location: "footer" })}
                  className="hover:text-primary"
                >
                  WhatsApp
                </a>
              </li>
              <li>
                <a
                  href={CONTACT.viber}
                  onClick={() => track("viber_click", { location: "footer" })}
                  className="hover:text-primary"
                >
                  Viber
                </a>
              </li>
            </ul>
          </nav>
        </div>
        <div className="container-lenart mt-12 border-t border-border pt-6 text-sm text-muted-foreground">
          © {new Date().getFullYear()} LENART · Novi Sad, Srbija
        </div>
      </footer>
    </div>
  );
}
