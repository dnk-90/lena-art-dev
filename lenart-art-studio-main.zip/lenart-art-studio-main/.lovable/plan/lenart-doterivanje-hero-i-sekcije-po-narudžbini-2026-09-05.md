# LENART — Doterivanje hero i sekcije „Po narudžbini”

## 1. Hero bedževi u jednom redu
- Bedževi „Ručno izrađeno · Jedinstveni radovi · Dostava širom sveta” ostaju u jednom redu (inline) dokle god širina dozvoljava: manji razmaci, kompaktniji tekst/ikone na srednjim ekranima, prelazak u dva reda tek na telefonima.

## 2. Sekcija „Po narudžbini” — novi raspored i stil
Trenutno: slika levo, desno tekst + koraci 2×2 + dugmad + napomena o Viberu.

Novo:
- **Rok izrade:** „Izrada do 14 dana.” → „Izrada od nedelju dana do mesec–dva, u zavisnosti od zahteva klijenta.” (serif akcenat ostaje)
- **Poravnanje sa slikom:** desna kolona se vizuelno poravnava sa slikom levo (vrh i ritam), bez praznog prostora — tekst, akcenat roka i CTA dugmad čine kompaktan blok.
- **Dugmad:** ostaju „Pošalji svoju ideju” (primarno), WhatsApp i Viber; **uklanja se** napomena „Ako Viber ne može da se otvori, pozovite 064 490 5335.”
- **Koraci 01–04 u novom redu ispod cele sekcije:** puna širina, 4 kolone na desktopu (2 na tabletu, 1 na telefonu), svaki korak sa zlatnim brojem, naslovom i opisom.
- **Stilizacija sekcije:** manje „obično” — koraci dobijaju tanke zlatne akcentne linije/brojeve, suptilna ivica ili peščana pozadina (postojeći `--sand`/`--gold` tonovi), vertikalni razdelnik između gornjeg bloka i koraka, blagi hover/transition detalji. Bez novih boja van postojeće palete.

## Tehnički detalji
- Sve izmene samo u `src/routes/index.tsx` (hero lista bedževa + sekcija `#po-narudzbini`).
- Koriste se postojeći tokeni: `eyebrow`, `h2-display`, `btn-base`, `border-border`, `text-gold`, `bg-sand`.
- Bez izmena podataka u `lenart.ts`; tracking događaji na dugmad ostaju.
